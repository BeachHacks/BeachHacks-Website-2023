import React from 'react'

export default function Our_Team() {
  return (
    <div>our team</div>
  )
}