import React from 'react'

export default function FAQ() {
  return (
    <div>FAQ</div>
  )
}