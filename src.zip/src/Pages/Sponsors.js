import React from 'react'

export default function Sponsors() {
  return (
    <div>Sponsors</div>
  )
}