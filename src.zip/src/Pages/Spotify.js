import React from 'react'

export default function Spotify() {
  return (
    <div>Spotify</div>
  )
}