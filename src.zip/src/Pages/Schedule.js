import React from 'react'

export default function Schedule() {
  return (
    <div>Schedule</div>
  )
}